
<?php
include "auth_check.php";
include "db.php";
if ($_SESSION['role'] != 'admin') { header("Location: login.php"); exit(); }
$id = $_GET['id'];
$query = "UPDATE emergency_bookings SET status='Cancelled' WHERE id='$id'";
mysqli_query($conn, $query);
header("Location: admin_dashboard.php");
?>
