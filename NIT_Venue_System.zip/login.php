
<!DOCTYPE html>
<html>
<head>
    <title>NIT Venue System | Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #0d6efd, #198754); height: 100vh; display: flex; align-items: center; justify-content: center; }
        .login-card { width: 400px; animation: fadeSlide 1.2s ease; border-radius: 15px; }
        @keyframes fadeSlide { from { transform: translateY(-50px); opacity:0; } to { transform: translateY(0); opacity:1; } }
        .logo { width: 90px; margin-bottom: 10px; }
        .system-title { font-weight: bold; color: #0d6efd; }
    </style>
</head>
<body>
<div class="card shadow login-card">
    <div class="card-body text-center">
        <!-- PLACE LOGO HERE -->
        <img src="assets/img/logo.png" class="logo" alt="NIT Logo">
        <h5 class="system-title">NIT Emergency Venue System</h5>
        <p class="text-muted mb-4">Login as Admin or CR</p>
        <form method="POST" action="login_process.php">
            <div class="mb-3 text-start">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3 text-start">
                <label>Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button class="btn btn-primary w-100">Login</button>
        </form>
    </div>
</div>
</body>
</html>
