
<?php
include "auth_check.php";
include "db.php";
if ($_SESSION['role'] != 'admin') { header("Location: login.php"); exit(); }
$query = "SELECT emergency_bookings.*, venues.venue_name FROM emergency_bookings JOIN venues ON emergency_bookings.venue_id = venues.id ORDER BY emergency_bookings.created_at DESC";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard | NIT Venue System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>.fade-in { animation: fadeIn 0.7s ease; } @keyframes fadeIn { from {opacity:0; transform:translateY(15px);} to {opacity:1; transform:translateY(0);} }</style>
</head>
<body class="bg-light">
<nav class="navbar navbar-dark bg-primary">
    <div class="container-fluid">
        <span class="navbar-brand">NIT Venue Admin Dashboard</span>
        <a href="logout.php" class="btn btn-light btn-sm">Logout</a>
    </div>
</nav>
<div class="container mt-4 fade-in">
    <a href="upload_timetable.php" class="btn btn-warning mb-3">Upload / Update Timetable</a>
    <div class="card shadow">
        <div class="card-header bg-success text-white">Emergency Bookings</div>
        <div class="card-body">
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr><th>Venue</th><th>Course</th><th>Booked By</th><th>Date</th><th>Time</th><th>Reason</th><th>Status</th><th>Action</th></tr>
                </thead>
                <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['venue_name'] ?></td>
                        <td><?= $row['course'] ?></td>
                        <td><?= $row['booked_by'] ?></td>
                        <td><?= $row['date'] ?></td>
                        <td><?= $row['start_time'] ?> - <?= $row['end_time'] ?></td>
                        <td><?= $row['reason'] ?></td>
                        <td><span class="badge <?= $row['status']=='Booked'?'bg-success':'bg-danger' ?>"><?= $row['status'] ?></span></td>
                        <td><?php if($row['status']=='Booked'){ ?>
                            <a href="cancel_booking.php?id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Cancel this booking?');">Cancel</a>
                        <?php } else { echo "-"; } ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</body>
</html>
