
<?php
$conn = mysqli_connect("localhost", "root", "", "nit_venue_system");
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
?>
