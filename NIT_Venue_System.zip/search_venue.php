
<?php
include "auth_check.php";
include "db.php";
$day = $_POST['day'];
$start = $_POST['start_time'];
$end = $_POST['end_time'];
$query = "
SELECT * FROM venues 
WHERE id NOT IN (
    SELECT venue_id FROM timetable WHERE day='$day' AND ('$start' < end_time AND '$end' > start_time)
) AND id NOT IN (
    SELECT venue_id FROM emergency_bookings WHERE date=CURDATE() AND ('$start' < end_time AND '$end' > start_time)
)";
$result = mysqli_query($conn, $query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Free Venues</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .fade-in { animation: fadeIn 0.8s ease; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body class="bg-light">
<div class="container mt-5 fade-in">
    <div class="card shadow">
        <div class="card-header bg-success text-white">Available Free Venues</div>
        <div class="card-body">
            <?php if (mysqli_num_rows($result) > 0) { ?>
            <table class="table table-bordered table-hover">
                <thead class="table-light">
                    <tr><th>Venue</th><th>Capacity</th><th>Location</th><th>Action</th></tr>
                </thead>
                <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?= $row['venue_name'] ?></td>
                        <td><?= $row['capacity'] ?></td>
                        <td><?= $row['location'] ?></td>
                        <td>
                            <a href="book_form.php?venue_id=<?= $row['id'] ?>&start=<?= $start ?>&end=<?= $end ?>"
                               class="btn btn-primary btn-sm"
                               onclick="return confirm('Do you want to book this venue for emergency session?');">Book Now</a>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>
            <?php } else { ?>
                <div class="alert alert-danger">No free venue available for selected time.</div>
            <?php } ?>
        </div>
    </div>
</div>
</body>
</html>
