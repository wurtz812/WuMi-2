
<?php
include "auth_check.php";
include "db.php";
$venue_id = $_POST['venue_id'];
$course = $_POST['course'];
$booked_by = $_POST['booked_by'];
$start = $_POST['start_time'];
$end = $_POST['end_time'];
$date = date('Y-m-d');
$reason = $_POST['reason'];
$query = "INSERT INTO emergency_bookings (venue_id, course, booked_by, date, start_time, end_time, reason)
VALUES ('$venue_id','$course','$booked_by','$date','$start','$end','$reason')";
mysqli_query($conn, $query);
echo "<script>alert('Venue booked successfully!'); window.location='search.html';</script>";
?>
