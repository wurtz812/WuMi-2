
<?php
include "auth_check.php";
include "db.php";
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;
$file = $_FILES['excel']['tmp_name'];
$spreadsheet = IOFactory::load($file);
$sheet = $spreadsheet->getActiveSheet();
$data = $sheet->toArray();
mysqli_query($conn, "DELETE FROM timetable");
for ($i=1;$i<count($data);$i++){
    $course=$data[$i][0]; $venue_id=$data[$i][1]; $day=$data[$i][2]; $start=$data[$i][3]; $end=$data[$i][4];
    $query="INSERT INTO timetable (course,venue_id,day,start_time,end_time) VALUES ('$course','$venue_id','$day','$start','$end')";
    mysqli_query($conn,$query);
}
echo "<script>alert('Timetable uploaded successfully!'); window.location='admin_dashboard.php';</script>";
?>
