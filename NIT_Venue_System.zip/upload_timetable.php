
<?php
include "auth_check.php";
if ($_SESSION['role'] != 'admin') { header("Location: login.php"); exit(); }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Upload Timetable | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">Upload Main Timetable (Excel)</div>
        <div class="card-body">
            <form method="POST" action="upload_process.php" enctype="multipart/form-data">
                <div class="mb-3">
                    <label>Select Excel File (.xls or .xlsx)</label>
                    <input type="file" name="excel" class="form-control" required>
                </div>
                <button class="btn btn-success">Upload Timetable</button>
                <a href="admin_dashboard.php" class="btn btn-secondary">Back</a>
            </form>
        </div>
    </div>
</div>
</body>
</html>
