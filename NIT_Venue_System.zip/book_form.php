
<?php
include "auth_check.php";
$venue_id = $_GET['venue_id'];
$start = $_GET['start'];
$end = $_GET['end'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Emergency Booking</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header bg-primary text-white">Emergency Venue Booking</div>
        <div class="card-body">
            <form method="POST" action="book_process.php">
                <input type="hidden" name="venue_id" value="<?= $venue_id ?>">
                <input type="hidden" name="start_time" value="<?= $start ?>">
                <input type="hidden" name="end_time" value="<?= $end ?>">
                <div class="mb-3">
                    <label>Course</label>
                    <input type="text" name="course" class="form-control" required placeholder="Enter course name">
                </div>
                <div class="mb-3">
                    <label>Booked By (CR Name)</label>
                    <input type="text" name="booked_by" class="form-control" required placeholder="Your name">
                </div>
                <div class="mb-3">
                    <label>Reason</label>
                    <textarea name="reason" class="form-control" required placeholder="Reason for emergency booking"></textarea>
                </div>
                <button class="btn btn-success">Confirm Booking</button>
                <a href="search.html" class="btn btn-secondary">Cancel</a>
            </form>
        </div>
    </div>
</div>
</body>
</html>
