
<?php
session_start();
include "db.php";
$email = $_POST['email'];
$password = md5($_POST['password']);
$query = "SELECT * FROM users WHERE email='$email' AND password='$password'";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) == 1) {
    $user = mysqli_fetch_assoc($result);
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['name'] = $user['name'];
    $_SESSION['role'] = $user['role'];
    if ($user['role'] == 'admin') { header("Location: admin_dashboard.php"); }
    else { header("Location: search.html"); }
} else {
    echo "<script>alert('Invalid login details'); window.location='login.php';</script>";
}
?>
